# Drone Carrier Board (FLYING WEDGE) — internship project

KiCad 9 project, files exactly as supplied (not modified).

| File | What it is |
|---|---|
| `19.kicad_pro` / `19.kicad_pcb` | KiCad project and 2-layer PCB (1.6 mm, ~94 footprints) |
| `untitled.kicad_sch` | root schematic sheet ("CARRIER BOARD", dated 22-4-2025) |
| `untitled.kicad_sch3.kicad_sch`, `untitled.kicad_sch1.kicad_sch` | sub-sheets (referenced from the root sheet) |
| `untitled.kicad_sch1.kicad_sch-bak` | KiCad auto-backup of sub-sheet 1 |
| `KICAD_SCHEMATIC_OF_CARRIER_BOARD.pdf` | 4-page schematic print |

Content, from the schematic: an 80-pin Hirose DF17 FMU connector carrying SERIAL1–5, CAN1–3, I2C1–2, SPI, SWD, RC/PPM-S.BUS, servo power and battery sense signals, plus servo/peripheral headers, EMI filters and SMAJ30A TVS protection.

Notes
* Open `untitled.kicad_sch` as the root sheet. The project file lists `19.kicad_sch` as its top-level sheet, which was not in the upload, so KiCad may ask you to locate it.
* ERC/DRC were **not** run on this project: the environment used here has KiCad 7, which cannot open KiCad 9 files. Run Inspect → ERC / DRC in KiCad 9 before submitting.
